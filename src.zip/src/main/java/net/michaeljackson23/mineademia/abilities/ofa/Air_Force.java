package net.michaeljackson23.mineademia.abilities.ofa;

import net.michaeljackson23.mineademia.abilities.abilityinit.IAbilityHandler;
import net.michaeljackson23.mineademia.entity.projectile.airforce.AirForceProjectile;
import net.michaeljackson23.mineademia.init.PlayerData;
import net.michaeljackson23.mineademia.util.PlayerAngleVector;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

public class Air_Force implements IAbilityHandler {
    public static final String title = "Air Force";
    public static final String description = "The user flicks their fingers and creates intense wind pressure";

    @Override
    public void activate(ServerPlayerEntity player, PlayerData playerState, MinecraftServer server, int slot) {
        server.execute(() -> {
            player.addVelocity(PlayerAngleVector.getPlayerAngleVector(player, -0.5, -0.5));
            player.velocityModified = true;

            AirForceProjectile airForceProjectile = new AirForceProjectile(player.getWorld(), player);
            airForceProjectile.setVelocity(player, player.getPitch(), player.getYaw(), 0f, 2f, 0);
            player.getWorld().spawnEntity(airForceProjectile);

            player.swingHand(player.getActiveHand(), true);

            playerState.quirkAbilityTimers[slot]++;
            if(playerState.quirkAbilityTimers[slot] >= 2) {
                playerState.quirkAbilityTimers[slot] = 0;
            }
        });
    }
}
