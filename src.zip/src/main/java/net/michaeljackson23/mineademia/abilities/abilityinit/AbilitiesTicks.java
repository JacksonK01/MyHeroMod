package net.michaeljackson23.mineademia.abilities.abilityinit;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.michaeljackson23.mineademia.abilities.abilityinit.AbilityMap;
import net.michaeljackson23.mineademia.hud.DevQuirkDisplay;
import net.michaeljackson23.mineademia.init.PlayerData;
import net.michaeljackson23.mineademia.init.StateSaverAndLoader;

public class AbilitiesTicks {
    public static void AbilitiesTickEvent() {
        ServerTickEvents.START_SERVER_TICK.register((server) -> {
            server.getPlayerManager().getPlayerList().forEach((player) -> {
                PlayerData playerState = StateSaverAndLoader.getPlayerState(player);
                if(playerState.quirkAbilityTimers[0] >= 1) {
                    AbilityMap.abilityMap.get(playerState.quirkAbilities[0]).activate(player, playerState, server, 0);
                } else if (playerState.quirkAbilityTimers[1] >= 1) {
                    AbilityMap.abilityMap.get(playerState.quirkAbilities[1]).activate(player, playerState, server, 1);
                } else if (playerState.quirkAbilityTimers[2] >= 1) {
                    AbilityMap.abilityMap.get(playerState.quirkAbilities[2]).activate(player, playerState, server, 2);
                } else if (playerState.quirkAbilityTimers[3] >= 1) {
                    AbilityMap.abilityMap.get(playerState.quirkAbilities[3]).activate(player, playerState, server, 3);
                } else if (playerState.quirkAbilityTimers[4] >= 1) {
                    AbilityMap.abilityMap.get(playerState.quirkAbilities[4]).activate(player, playerState, server, 4);
                }
                //Sending this info to update the hud
//                DevQuirkDisplay.playerQuirk = playerState.playerQuirk;
//                DevQuirkDisplay.abilityOne = playerState.quirkAbilityTimers[0];
//                DevQuirkDisplay.abilityTwo = playerState.quirkAbilityTimers[1];

            });
        });
    }
}
