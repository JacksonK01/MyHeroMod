package net.michaeljackson23.mineademia.abilities.abilityinit;

import net.michaeljackson23.mineademia.abilities.QuirkAbilities;
import net.michaeljackson23.mineademia.abilities.ofa.Air_Force;
import net.michaeljackson23.mineademia.abilities.Empty;
import net.michaeljackson23.mineademia.abilities.ofa.Blackwhip;

import java.util.HashMap;
import java.util.Map;

public class AbilityMap {
    public static Map<Integer, IAbilityHandler> abilityMap = new HashMap<>();
    public static void LoadAbilityMap() {
        abilityMap.put(QuirkAbilities.EMPTY.getValue(), new Empty());
        abilityMap.put(QuirkAbilities.AIR_FORCE.getValue(), new Air_Force());
        abilityMap.put(QuirkAbilities.BLACKWHIP.getValue(), new Blackwhip());
    }
}
