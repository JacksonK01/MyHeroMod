package net.michaeljackson23.mineademia.abilities;

import net.michaeljackson23.mineademia.abilities.abilityinit.IAbilityHandler;
import net.michaeljackson23.mineademia.init.PlayerData;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

public class Empty implements IAbilityHandler {
    //I just need this here for the map
    @Override
    public void activate(ServerPlayerEntity player, PlayerData playerData, MinecraftServer server, int slot) {

    }
}
