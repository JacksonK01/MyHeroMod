package net.michaeljackson23.mineademia.abilities.ofa;

import net.michaeljackson23.mineademia.abilities.abilityinit.IAbilityHandler;
import net.michaeljackson23.mineademia.init.PlayerData;
import net.michaeljackson23.mineademia.util.Raycast;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;


public class Blackwhip implements IAbilityHandler {
    public static final String title = "Blackwhip";
    public static final String description = "Blackwhip grants the user the ability to produce energy tendrils from any part of their body and command them at will";

    @Override
    public void activate(ServerPlayerEntity player, PlayerData playerData, MinecraftServer server, int slot) {
        HitResult result = Raycast.start(player, player.getWorld(), 20);
        player.sendMessage(Text.literal("Timer: " + playerData.quirkAbilityTimers[slot]));
        if (result.getType() == HitResult.Type.BLOCK) {
            BlockHitResult blockHitResult = (BlockHitResult) result;

            playerData.storedXBlackwhip = blockHitResult.getBlockPos().toCenterPos().getX();
            playerData.storedYBlackwhip = blockHitResult.getBlockPos().toCenterPos().getY();
            playerData.storedZBlackwhip = blockHitResult.getBlockPos().toCenterPos().getZ();
        }
        if(!player.getWorld().isAir(new BlockPos((int) playerData.storedXBlackwhip, (int) playerData.storedYBlackwhip, (int) playerData.storedZBlackwhip))) {
            if(playerData.quirkAbilityTimers[slot] >= 1) {
                // Calculate the number of particles to create for the line
                int numberOfParticles = 50;

                // Calculate the step size for interpolation
                double stepSize = 1.0 / numberOfParticles;

                double playerX = player.getX();
                double playerY = player.getY() + 1;
                double playerZ = player.getZ();

                // Spawn particles in a line between the player and the hit block
                for (double t = 0; t <= 1.0; t += stepSize) {
                    double interpolatedX = playerX + t * (playerData.storedXBlackwhip - playerX);
                    double interpolatedY = playerY + t * (playerData.storedYBlackwhip - playerY);
                    double interpolatedZ = playerZ + t * (playerData.storedZBlackwhip - playerZ);

                    player.getServerWorld().spawnParticles(ParticleTypes.ENCHANTED_HIT, interpolatedX, interpolatedY, interpolatedZ, 1, 0.0f, 0.0f, 0.0f, 0);
                }

            }
        }
        else {
            playerData.quirkAbilityTimers[slot] = 0;
        }
        if(player.isSneaking()) {
            playerData.quirkAbilityTimers[slot] = 0;
        }
        if(playerData.quirkAbilityTimers[slot] != 999) {
            playerData.quirkAbilityTimers[slot]++;
        }
    }
}
