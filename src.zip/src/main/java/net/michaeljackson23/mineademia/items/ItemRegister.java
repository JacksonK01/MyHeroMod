package net.michaeljackson23.mineademia.items;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.michaeljackson23.mineademia.Mineademia;
import net.michaeljackson23.mineademia.items.custom.QuirkTablet;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ItemRegister {

//    public Item ItemGenerator() {
//        Item item = new Item(new FabricItemSettings());
//        Registry.register(Registries.ITEM, new Identifier(Mineademia.Mod_id, "quirk_tablet"), item);
//        return item;
//    }

    public static void register() {
        QuirkTablet quirkTablet = Registry.register(Registries.ITEM, new Identifier(Mineademia.Mod_id, "quirk_menu_selector"), new QuirkTablet(new FabricItemSettings().maxCount(1)));


        ItemGroup MHA_GROUP = FabricItemGroup.builder()
                .icon(() -> new ItemStack(quirkTablet))
                .displayName(Text.translatable("itemGroup.mineademia.item_group"))
                .entries((context, entries) -> {
                    entries.add(quirkTablet);
                })
                .build();
        Registry.register(Registries.ITEM_GROUP, new Identifier(Mineademia.Mod_id, "mha_group"), MHA_GROUP);
    }
}
