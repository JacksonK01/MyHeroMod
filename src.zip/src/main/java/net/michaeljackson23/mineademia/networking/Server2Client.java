package net.michaeljackson23.mineademia.networking;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.michaeljackson23.mineademia.Mineademia;
import net.michaeljackson23.mineademia.gui.quirktablet.QuirkTabletGui;
import net.michaeljackson23.mineademia.hud.DevQuirkDisplay;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class Server2Client {
    //This class is when the client needs to listen for a packet sent by the server
    public static final Identifier INITIAL_SYNC = new Identifier(Mineademia.Mod_id, "initial_sync");
    public static final Identifier QUIRK_TABLET_GUI = new Identifier(Mineademia.Mod_id, "quirk_tablet_gui");
    public static final Identifier CHANGED_QUIRK = new Identifier(Mineademia.Mod_id, "changed_quirk");


    //This is just for the HUD
    private static String playerQuirk;


    public static void setPlayerQuirk(String quirk) {
        playerQuirk = quirk;
    }

    public static String getQuirk() {
        return playerQuirk;
    }

    public static void registerServerToClientPackets() {
        Mineademia.LOGGER.info("Registering all Server to Client event listener");
        ClientPlayNetworking.registerGlobalReceiver(INITIAL_SYNC, (client, handler, buf, responseSender) -> {
            String quirk = buf.readString();
            int[] quirkAbilities = buf.readIntArray();
            int[] quirkAbilityTimers = buf.readIntArray();
            int quirkCooldown = buf.readInt();
            setPlayerQuirk(playerQuirk);

            client.execute(() -> {
                client.player.sendMessage(Text.literal("Initialized Quirk: "+quirk));
                client.player.sendMessage(Text.literal("Abilities: "+quirkAbilities[0]));
                client.player.sendMessage(Text.literal("Ability Timers: "+quirkAbilityTimers[0]));
                client.player.sendMessage(Text.literal("Cooldown: "+quirkCooldown));
            });
        });
        //When the button is pressed on the tablet, it sends this packet for functionality
        ClientPlayNetworking.registerGlobalReceiver(QUIRK_TABLET_GUI, (client, handler, buf, responseSender) -> {
            client.execute(() -> {
                QuirkTabletGui quirkTabletGui = new QuirkTabletGui(Text.literal("Quirk Tablet"));
                quirkTabletGui.init(client, 50, 50);
                quirkTabletGui.shouldPause();
                client.setScreenAndRender(quirkTabletGui);
            });
        });
        ClientPlayNetworking.registerGlobalReceiver(CHANGED_QUIRK, (client, handler, buf, responseSender) -> {
            client.execute(() -> {
                String quirk = buf.readString();
                setPlayerQuirk(quirk);
            });
        });
    }
}
