package net.michaeljackson23.mineademia.keybinds;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import org.lwjgl.glfw.GLFW;

import static net.michaeljackson23.mineademia.networking.Client2Server.ABILITY_ONE;
import static net.michaeljackson23.mineademia.networking.Client2Server.ABILITY_TWO;

public class Keybinds {
    private static KeyBinding keyAbilityOne;
    private static KeyBinding keyAbilityTwo;
    private static KeyBinding keyAbilityThree;
    private static KeyBinding keyAbilityFour;
    private static KeyBinding keyAbilityFive;

    public Keybinds() {
        keyAbilityOne = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mineademia.ability_one",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "key.mineademia.mineademia"
        ));
        keyAbilityTwo = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mineademia.ability_two",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "key.mineademia.mineademia"
        ));
        keyAbilityThree = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mineademia.ability_three",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_Z,
                "key.mineademia.mineademia"
        ));
        keyAbilityFour = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mineademia.ability_four",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_X,
                "key.mineademia.mineademia"
        ));
        keyAbilityFive = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mineademia.ability_five",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_C,
                "key.mineademia.mineademia"
        ));
    }

    public static void keybindActions() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (keyAbilityOne.wasPressed()) {
                PacketByteBuf data = PacketByteBufs.create();
                ClientPlayNetworking.send(ABILITY_ONE, data);
            }
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (keyAbilityTwo.wasPressed()) {
                PacketByteBuf data = PacketByteBufs.create();
                ClientPlayNetworking.send(ABILITY_TWO, data);
            }
        });
    }

}
