package net.michaeljackson23.mineademia.init;

import java.util.ArrayList;
import java.util.List;

public class PlayerData {
    //This is all the information I store onto the player
    public String playerQuirk;
    public int[] quirkAbilities = new int[5];
    public int[] quirkAbilityTimers = new int[5];
    public int quirkCooldown;
    public int quirkStamina;
    //This is for leveling up your quirk, I don't know what I'll use it for yet
    public List<Integer> quirkStats = new ArrayList<>();
    public double storedXBlackwhip;
    public double storedYBlackwhip;
    public double storedZBlackwhip;

    public PlayerData() {
        this.playerQuirk = "empty";

        for(int i = 0;i < quirkAbilities.length;i++) {
            quirkAbilities[i] = 0;
        }

        for(int i = 0;i < quirkAbilityTimers.length;i++) {
            quirkAbilityTimers[i] = 0;
        }

        this.quirkCooldown = 0;

        this.quirkStamina = 1000;

        quirkStats.add(0);
        quirkStats.add(0);
        quirkStats.add(0);

        this.storedXBlackwhip = 0;
        this.storedYBlackwhip = 0;
        this.storedZBlackwhip = 0;
    }
}
