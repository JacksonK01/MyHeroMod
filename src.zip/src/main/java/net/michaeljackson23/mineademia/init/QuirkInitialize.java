package net.michaeljackson23.mineademia.init;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.michaeljackson23.mineademia.abilities.QuirkAbilities;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Random;

import static net.michaeljackson23.mineademia.networking.Server2Client.CHANGED_QUIRK;
import static net.michaeljackson23.mineademia.networking.Server2Client.INITIAL_SYNC;

public class QuirkInitialize {
    private static List<String> allQuirks = List.of("One For All", "Explosion", "Half-Cold Half-Hot", "Whirlwind", "Electrification");

    public static void InitializeEvent() {
        ServerPlayConnectionEvents.JOIN.register(((handler, sender, server) -> {
            handler.getPlayer().sendMessage(Text.literal("Player join world event is working!!"));
            PlayerData playerData = StateSaverAndLoader.getPlayerState(handler.getPlayer());
            PacketByteBuf data = PacketByteBufs.create();

            if(playerData.playerQuirk.equals("empty")) {
                playerData = QuirkInitialize.quirkSetup(playerData, handler.getPlayer(), "empty");
            }

            data.writeString(playerData.playerQuirk);
            data.writeIntArray(playerData.quirkAbilities);
            data.writeIntArray(playerData.quirkAbilityTimers);
            data.writeInt(playerData.quirkCooldown);
            for (int quirkStat : playerData.quirkStats) {
                data.writeInt(quirkStat);
            }
            server.execute(() -> {
                ServerPlayNetworking.send(handler.getPlayer(), INITIAL_SYNC, data);
            });
        }));
    }

    public static String changeQuirk() {
        Random rand = new Random();
        int randomInt = rand.nextInt(allQuirks.size());
        return allQuirks.get(randomInt);
    }

    public static int[] abilityRegister(String quirk) {
        int[] abilities = new int[5];

        for(int i = 0;i < abilities.length;i++) {
            abilities[i] = 0;
        }

        if(quirk.equals("One For All")) {
            abilities[0] = QuirkAbilities.AIR_FORCE.getValue();
            abilities[1] = QuirkAbilities.BLACKWHIP.getValue();
        }
        return abilities;
    }
    public static void sendPacket(String quirk, ServerPlayerEntity player) {
        PacketByteBuf data = PacketByteBufs.create();
        data.writeString(quirk);
        ServerPlayNetworking.send(player, CHANGED_QUIRK, data);
    }

    public static PlayerData quirkSetup(PlayerData playerData, ServerPlayerEntity player, String quirk) {
        if (quirk.equals("empty")) {
            playerData.playerQuirk = changeQuirk();
            playerData.quirkAbilities = abilityRegister(playerData.playerQuirk);
            sendPacket(playerData.playerQuirk, player);
            return playerData;
        }
        else {
            playerData.playerQuirk = quirk;
            playerData.quirkAbilities = abilityRegister(playerData.playerQuirk);
            sendPacket(playerData.playerQuirk, player);
            return playerData;
        }
    }
}

